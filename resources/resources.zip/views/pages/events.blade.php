@extends('layouts.index')

@section('content')
<x-pagetitle name="Events" imgUrl="img/ewings-05.png" />
<div class="container">
    <h2 class="text-center" style="line-height: 400px; height: 400px">Content Goes Here</h2>
</div>

@endsection
