@extends('layouts.index')

@section('content')
<x-pagetitle name="About" imgUrl="img/ewings-05.png" />
<!-- start about us section -->
<section class="about-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-sm-12 order-2 order-lg-1">
                <div class="padding-50px-right md-padding-40px-right sm-no-padding-right">
                    <h3 class="font-weight-500 font-size32 md-font-size28 sm-font-size26 xs-font-size24 margin-30px-bottom md-margin-25px-bottom sm-margin-20px-bottom text-theme-color">Welcome to our campus</h3>
                    <p class="margin-30px-bottom md-margin-25px-bottom sm-margin-20px-bottom font-size16 line-height-30">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled unchanged.</p>
                    <ul class="list-style5">
                        <li>Building our community</li>
                        <li>Book, library and store</li>
                    </ul>
                    <a class="butn fill margin-30px-top md-margin-25px-top sm-margin-20px-top" href="/ewings/about">Read More <i class="fas fa-long-arrow-alt-right margin-10px-left"></i></a>
                </div>
            </div>

            <div class="col-lg-7 col-sm-12 order-1 order-lg-2 sm-margin-40px-bottom xs-margin-30px-bottom">
                <div class="row">
                    <div class="col-md-7 xs-margin-25px-bottom">
                        <div class="xs-text-center">
                            <img src="{{asset('img/content/about01.jpg')}}" alt="" class="border-radius-6" />
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="about-img">
                            <img src="{{asset('img/content/about02.jpg')}}" alt="" class="margin-30px-bottom sm-margin-25px-bottom border-radius-6" />
                            <img src="{{asset('img/content/about03.jpg')}}" alt="" class="border-radius-6" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end about us section -->

<!-- start testimonials section -->
<section class="bg-light-gray">
    <div class="container">
        <div class="row">
            <div class="col-12 center-col margin-50px-bottom sm-margin-40px-bottom text-center">
                <h3 class="font-weight-500 font-size32 md-font-size28 sm-font-size26 xs-font-size24 section-title">What Parents Say</h3>
                <div class="title-border"><span class="lg"></span><span class="md"></span><span class="sm"></span></div>
            </div>
        </div>
        <div class="testimonial-style1 owl-theme owl-carousel" data-slider-id="1">
            <div class="text-center">
                <div class="testmonial-text">
                    <p class="font-size18 sm-font-size16 line-height-35 xs-line-height-28 margin-30px-bottom sm-margin-25px-bottom xs-margin-20px-bottom">Perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque inventore veritatis et quasi architecto beatae.</p>
                    <h5 class="margin-5px-bottom font-size18 xs-font-size16"><a href="#" class="text-theme-color">Stepha Kruse</a></h5>
                    <h6 class="font-size14 xs-font-size13 letter-spacing-1 font-weight-500 opacity6 no-margin-bottom">Designer</h6>
                </div>
            </div>
            <div class="text-center">
                <div class="testmonial-text">
                    <p class="font-size18 sm-font-size16 line-height-35 xs-line-height-28 margin-30px-bottom sm-margin-25px-bottom xs-margin-20px-bottom">Aerspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque inventore veritatis et quasi architecto beatae.</p>
                    <h5 class="margin-5px-bottom font-size18 xs-font-size16"><a href="#" class="text-theme-color">Dunican keithly</a></h5>
                    <h6 class="font-size14 xs-font-size13 letter-spacing-1 font-weight-500 opacity6 no-margin-bottom">Networking</h6>
                </div>
            </div>
            <div class="text-center">
                <div class="testmonial-text">
                    <p class="font-size18 sm-font-size16 line-height-35 xs-line-height-28 margin-30px-bottom sm-margin-25px-bottom xs-margin-20px-bottom">Rerspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque inventore veritatis et quasi architecto beatae.</p>
                    <h5 class="margin-5px-bottom font-size18 xs-font-size16"><a href="#" class="text-theme-color">Alivin Corondo</a></h5>
                    <h6 class="font-size14 xs-font-size13 letter-spacing-1 font-weight-500 opacity6 no-margin-bottom">Developer</h6>
                </div>
            </div>
        </div>
        <div class="owl-thumbs text-center" data-slider-id="1">
            <button class="owl-thumb-item border-radius-50 width-60px sm-width-50px xs-width-40px margin-5px-right"><img src="{{asset('img/testmonials/t-7.jpg')}}" class="border-radius-50" alt="" /></button>
            <button class="owl-thumb-item width-60px border-radius-50 sm-width-50px xs-width-40px margin-5px-right"><img src="{{asset('img/testmonials/t-8.jpg')}}" class="border-radius-50" alt="" /></button>
            <button class="owl-thumb-item width-60px sm-width-50px xs-width-40px border-radius-50"><img src="{{asset('img/testmonials/t-9.jpg')}}" class="border-radius-50" alt="" /></button>
        </div>
    </div>
</section>
<!-- end testimonials section -->

<!-- start our team section -->
<section>
    <div class="container">
        <div class="row">
            <div class="col-12 center-col margin-50px-bottom sm-margin-40px-bottom text-center">
                <h3 class="font-weight-500 font-size32 md-font-size28 sm-font-size26 xs-font-size24 section-title">Our Experience advisor</h3>
                <div class="title-border"><span class="lg"></span><span class="md"></span><span class="sm"></span></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 xs-margin-30px-bottom">
                <div class="team-block">
                    <div class="team-image position-relative display-block overflow-hidden">
                        <img src="{{asset('img/team/team-05.jpg')}}" alt="" />
                        <div class="overlay-box">
                            <ul class="social-icons no-margin-bottom">
                                <li><a href="javascript:void(0)"><span><i class="fab fa-facebook-f"></i></span></a></li>
                                <li><a href="javascript:void(0)"><span><i class="fab fa-twitter"></i></span></a></li>
                                <li><a href="javascript:void(0)"><span><i class="fab fa-linkedin-in"></i></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team-info padding-20px-tb md-padding-15px-tb padding-5px-lr text-center">
                        <h5 class=" font-size20 sm-font-size18 text-theme-color margin-5px-bottom sm-no-margin-bottom">Matide V. Sousa</h5>
                        <div class="team-position">Graphic Designer</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 xs-margin-30px-bottom">
                <div class="team-block">
                    <div class="team-image position-relative display-block overflow-hidden">
                        <img src="{{asset('img/team/team-04.jpg')}}" alt="" />
                        <div class="overlay-box">
                            <ul class="social-icons no-margin-bottom">
                                <li><a href="javascript:void(0)"><span><i class="fab fa-facebook-f"></i></span></a></li>
                                <li><a href="javascript:void(0)"><span><i class="fab fa-twitter"></i></span></a></li>
                                <li><a href="javascript:void(0)"><span><i class="fab fa-linkedin-in"></i></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team-info padding-20px-tb md-padding-15px-tb padding-5px-lr text-center">
                        <h5 class=" font-size20 sm-font-size18 text-theme-color margin-5px-bottom sm-no-margin-bottom">Donna C. Adams</h5>
                        <div class="team-position">App Developer</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="team-block">
                    <div class="team-image position-relative display-block overflow-hidden">
                        <img src="{{asset('img/team/team-06.jpg')}}" alt="" />
                        <div class="overlay-box">
                            <ul class="social-icons no-margin-bottom">
                                <li><a href="javascript:void(0)"><span><i class="fab fa-facebook-f"></i></span></a></li>
                                <li><a href="javascript:void(0)"><span><i class="fab fa-twitter"></i></span></a></li>
                                <li><a href="javascript:void(0)"><span><i class="fab fa-linkedin-in"></i></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team-info padding-20px-tb md-padding-15px-tb padding-5px-lr text-center">
                        <h5 class=" font-size20 sm-font-size18 text-theme-color margin-5px-bottom sm-no-margin-bottom">Alice K. Jones</h5>
                        <div class="team-position">Creative Arts</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end our team section -->


@endsection
