@extends('layouts.index')

@section('content')
<x-pagetitle name="Blogs" imgUrl="img/bg/page-title.jpg" />
<div class="container">
    <h2 class="text-center" style="line-height: 400px; height: 400px">Content Goes Here</h2>
</div>

@endsection
